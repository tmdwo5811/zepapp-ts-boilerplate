/**
 * Copyright (c) 2022 ZEP Co., LTD
 */
App.showCenterLabel("Hello World");
let zepLogo = App.loadSpritesheet("zep_logo.png");
Map.putObject(0, 0, zepLogo, {
  overlap: true
});
App.onDestroy.Add(function () {
  Map.clearAllObjects();
});